Select 
	EMP.AllName,EMP.EmpCode,L.LoanAm,L.Remark,L.PayMonth,EMP.Branch,HRCompany.Images as Logo
From HREmpLoan L
Left Join HRStaffProfile EMP ON EMP.EmpCode=L.EmpCode
Left Join HRPosition P ON P.Code=EMP.JobCode
Left Join HRDepartment D ON D.Code=EMP.DEPT
LEFT JOIN HRCompany ON HRCompany.Company=EMP.CompanyCode
LEFT JOIN HRBranch ON HRBranch.Code=EMP.Branch AND HRBranch.CompanyCode=EMP.CompanyCode
Where 
	month(L.PayMonth)= month(@InMonth)and year(@InMonth)=YEAR(L.PayMonth) 
  AND (@Company IS NULL OR @Company='' OR  EMP.CompanyCode IN (SELECT Value FROM fn_Split(@Company, ','))) 
  AND (@Branch IS NULL OR @Branch='' OR  EMP.Branch  IN (SELECT Value FROM dbo.fn_Split(@Branch, ','))) 
  AND (@Division IS NULL OR @Division='' OR  EMP.Division=@Division) 
  AND (@Department IS NULL OR @Department='' OR  EMP.DEPT=@Department) 
  AND (@Section IS NULL OR @Section='' OR  EMP.SECT=@Section) 
  AND (@Position IS NULL OR @Position='' OR  EMP.JobCode=@Position) 
  AND (@Level IS NULL OR @Level='' OR  EMP.LevelCode=@Level)
